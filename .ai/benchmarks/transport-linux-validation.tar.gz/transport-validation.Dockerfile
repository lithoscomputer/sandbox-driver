FROM rust:1-bookworm AS rust
FROM ghcr.io/lithoscomputer/ubuntu-24.04-full:20260823.101.1-arm64
USER root
COPY --from=rust /usr/local/rustup /opt/transport-rustup
COPY --from=rust /usr/local/cargo/bin /opt/transport-cargo/bin
ENV RUSTUP_HOME=/opt/transport-rustup CARGO_HOME=/opt/transport-cargo CARGO_TARGET_DIR=/target
ENV PATH=/opt/transport-cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
WORKDIR /workspace
CMD ["sleep", "infinity"]
