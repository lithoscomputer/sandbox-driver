"""Summarize local transport evidence without combining overlapping socket counters."""
import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
names = ['rate', 'bulk', 'tiny', 'cycles', 'burst', 'endurance']
report = {'runs': []}
for name in names:
    path = root / f'transport-linux-{name}.jsonl'
    if not path.exists():
        continue
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    for row in rows[1:]:
        m = row['measurement']
        resources = [json.loads(line) for line in (root / Path(row['resources']).name).read_text().splitlines()]
        trace = [json.loads(line) for line in (root / Path(row['telemetry']).name).read_text().splitlines()]
        identity = trace[0]
        pids = {side: str(identity[f'{side}_pid']) for side in ['client', 'plugin']}
        baseline_samples = [r for r in resources if .25 < r['elapsed_seconds'] < 1.75 and len(r['processes']) == 2]
        baseline = baseline_samples[-1] if baseline_samples else None
        last = row['last_process_sample']
        active = [t for t in trace if t['phase'] == 'active']
        per_process = {side: max((r['processes'].get(pid, {}).get('rss_bytes', 0) for r in resources), default=0) for side, pid in pids.items()}
        socket_peaks = {}
        for r in resources:
            if r.get('socket_memory'):
                for key, value in r['socket_memory']['skmem'].items():
                    socket_peaks[key] = max(value, socket_peaks.get(key, 0))
        item = {
            'workload': name, 'operations': m['operations'], 'repetition': row['repetition'],
            'control': m['control'], 'setup': m['authenticated_setup'], 'first_byte': m['first_byte'],
            'startup_us': m['cold_start_us'], 'duration_seconds': m['duration_seconds'],
            'throughput_bytes_per_second': (m['active_transfer'] or {}).get('bytes_per_second'),
            'cpu_seconds_per_gib': row['cpu_seconds_per_gib'], 'cpu_seconds': row['cpu_seconds'],
            'completed_operations': m['completed_operations'], 'rejected_attempts': m['rejected_attempts'],
            'peak_rss_bytes': row['peak_client_and_plugin']['rss_bytes'], 'peak_rss_by_process': per_process,
            'peak_descriptors': row['peak_client_and_plugin']['descriptors'],
            'baseline_descriptors': baseline['descriptors'] if baseline else None,
            'settled_descriptors': last['descriptors'] if last else None,
            'remaining_socket_directories': row['remaining_socket_directories'],
            'kernel_socket_peaks': socket_peaks,
            'stop_to_local_completion_us': m['stop_to_local_completion_us'],
            'termination_confirmed': m['termination_confirmed'], 'abandoned_output': m['abandoned_output'],
            'stop_requests': m['after_cleanup']['client']['stop_requests'],
            'stop_acknowledgments': m['after_cleanup']['client']['stop_acknowledgments'],
            'max_stop_acknowledgment_us': m['after_cleanup']['client']['max_stop_acknowledgment_us'],
            'setup_samples_lost': m['after_cleanup']['client']['setup_samples_lost'],
            'baseline_runtime_tasks': [m['baseline'][s]['runtime_tasks'] for s in ['client', 'server']],
            'settled_runtime_tasks': [m['after_cleanup'][s]['runtime_tasks'] for s in ['client', 'server']],
            'active_diagnostic_samples': len(active),
            'all_active_samples_have_expected_io': all(t['diagnostics'][s]['active_io'] == m['operations'] for t in active for s in ['client', 'server']),
            'all_active_samples_have_expected_tasks': all(t['diagnostics']['client']['runtime_tasks'] == 2*m['operations']+4 and t['diagnostics']['server']['runtime_tasks'] == m['operations']+2 for t in active),
        }
        if name == 'endurance':
            item['active_transfer'] = m['active_transfer']
            item['memory_windows'] = []
            for start, end in [(60,120), (300,360), (600,660), (900,960), (1200,1260), (1500,1560), (1740,1800)]:
                values = [r['rss_bytes'] for r in resources if start <= r['elapsed_seconds'] <= end]
                item['memory_windows'].append({'from_seconds':start, 'to_seconds':end, 'samples':len(values), 'min_bytes':min(values), 'median_bytes':statistics.median(values), 'max_bytes':max(values)})
            item['active_descriptor_counts'] = sorted({r['descriptors'] for r in resources if 10 <= r['elapsed_seconds'] <= 1800})
        report['runs'].append(item)
(root / 'transport-linux-analysis.json').write_text(json.dumps(report, indent=2)+'\n')
for row in report['runs']:
    print(row['workload'],row['operations'],row['repetition'],'p99',row['control'].get('p99_us'),'FD',row['baseline_descriptors'],row['settled_descriptors'],'RSS MiB',round(row['peak_rss_bytes']/2**20,2))
